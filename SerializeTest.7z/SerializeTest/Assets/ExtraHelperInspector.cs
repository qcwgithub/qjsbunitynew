﻿using UnityEngine;
using UnityEditor;
using System.Collections;

[CustomEditor(typeof(ExtraHelper))]
public class JSComponentInspector : Editor
{
    public enum MyFieldType
    {
        Bool,
        Int,
        Float,
    }

    MyFieldType String2Enum(string s)
    {
        switch (s)
        {
            case "Bool": return MyFieldType.Bool; break;
            case "Int": return MyFieldType.Int; break;
            case "Float": return MyFieldType.Float; break;
            default: return MyFieldType.Bool;
        }
    }

    string Enum2String(MyFieldType e)
    {
        switch (e)
        {
            case MyFieldType.Bool: return "Bool"; break;
            case MyFieldType.Int: return "Int"; break;
            case MyFieldType.Float: return "Float"; break;
            default: return "Bool";
        }
    }

	
	static public bool DrawHeader (string text, string key, bool forceOn)
	{
		bool state = EditorPrefs.GetBool(key, true);

		GUILayout.Space(3f);
		if (!forceOn && !state) GUI.backgroundColor = new Color(0.8f, 0.8f, 0.8f);
		GUILayout.BeginHorizontal();
		GUILayout.Space(3f);

		GUI.changed = false;
#if UNITY_3_5
		if (state) text = "\u25B2 " + text;
		else text = "\u25BC " + text;
		if (!GUILayout.Toggle(true, text, "dragtab", GUILayout.MinWidth(20f))) state = !state;
#else
		text = "<b><size=11>" + text + "</size></b>";
		if (state) text = "\u25B2 " + text;
		else text = "\u25BC " + text;
		if (!GUILayout.Toggle(true, text, "dragtab", GUILayout.MinWidth(20f))) state = !state;
#endif
		if (GUI.changed) EditorPrefs.SetBool(key, state);

		GUILayout.Space(2f);
		GUILayout.EndHorizontal();
		GUI.backgroundColor = Color.white;
		if (!forceOn && !state) GUILayout.Space(3f);
		return state;
	}

	
	static public void BeginContents ()
	{
		GUILayout.BeginHorizontal();
		GUILayout.Space(4f);
		EditorGUILayout.BeginHorizontal("AS TextArea", GUILayout.MinHeight(10f));
		GUILayout.BeginVertical();
		GUILayout.Space(2f);
	}

	
	static public void EndContents ()
	{
		GUILayout.Space(3f);
		GUILayout.EndVertical();
		EditorGUILayout.EndHorizontal();
		GUILayout.Space(3f);
		GUILayout.EndHorizontal();
		GUILayout.Space(3f);
	}

    public override void OnInspectorGUI()
    {
        serializedObject.Update();

        ExtraHelper jsCom = target as ExtraHelper;

        if (DrawHeader("Fields", "Fields", false))
        {
            BeginContents();
            {
                ExtraHelper.ComSerializedField[] arr = jsCom.serializedArray;

                EditorGUILayout.BeginHorizontal();
                {
                    GUILayout.Space(4f);
                    EditorGUILayout.LabelField("Type", GUILayout.Width(50));
                    EditorGUILayout.LabelField("Name", GUILayout.Width(80));
                    EditorGUILayout.LabelField("Value", GUILayout.Width(50));
                }
                EditorGUILayout.EndHorizontal();

                int deleteIndex = -1;
                bool bAdd = false, bClear = false;
                for (int i = 0; i < arr.Length; i++)
                {
                    ExtraHelper.ComSerializedField field = arr[i];
                    if (field == null)
                        continue;

                    EditorGUILayout.BeginHorizontal();
                    {
                        GUILayout.Space(4f);

                        MyFieldType type = String2Enum(field.type);
                        MyFieldType newType = (MyFieldType)EditorGUILayout.EnumPopup(type, GUILayout.Width(50));
                        field.type = Enum2String(newType);
                        field.name = EditorGUILayout.TextField(field.name, GUILayout.Width(80));
                        switch (newType)
                        {
                            case MyFieldType.Bool:
                                if (type != newType) { field.value = false; }
                                field.value = EditorGUILayout.Toggle((bool)field.value, GUILayout.MinWidth(20));
                                break;

                            case MyFieldType.Int:
                                if (type != newType) { field.value = 0; }
                                field.value = (object)EditorGUILayout.IntField((int)field.value, GUILayout.MinWidth(20));
                                break;

                            case MyFieldType.Float:
                                if (type != newType) { field.value = 0f; }
                                field.value = (object)EditorGUILayout.FloatField((float)field.value, GUILayout.MinWidth(20));
                                break;

                            default:
                                break;
                        }

                        if (GUILayout.Button("X", GUILayout.Width(20)))
                        {
                            deleteIndex = i;
                        }
                    }
                    EditorGUILayout.EndHorizontal();
                }

                EditorGUILayout.BeginHorizontal();
                {
                    if (GUILayout.Button("Add")) bAdd = true;
                    if (GUILayout.Button("Clear")) bClear = true;
                }
                EditorGUILayout.EndHorizontal();

                if (deleteIndex >= 0)
                {
                    jsCom.DelSField(deleteIndex);
                }
                if (bAdd)
                {
                    jsCom.AddSField(Enum2String(MyFieldType.Bool), "", false);
                }
                if (bClear)
                {
                    jsCom.ClearSFields();
                }
            }
            EndContents();
        }
        
        base.OnInspectorGUI();
    }
}
