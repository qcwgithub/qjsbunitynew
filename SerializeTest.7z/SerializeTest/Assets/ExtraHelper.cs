﻿using System;
using UnityEngine;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Security;


public class ExtraHelper : MonoBehaviour, ISerializationCallbackReceiver
{
    /// <summary>
    /// Serialization Stuff
    /// </summary>

    [NonSerialized]
    public bool seralizeChanged = false;

    public class ComSerializedField
    {
        public ComSerializedField(string t, string n, object v) { type = t; name = n; value = v; }
        public string type;
        public string name;
        public object value;
    };
    // string for serialization
    public string serializedString = string.Empty;

    [NonSerialized]
    public ComSerializedField[] serializedArray = new ComSerializedField[0];
    int sCount = 0;
    public void AddSField(string t, string n, object v)
    {
        if (sCount < serializedArray.Length)
        {
            serializedArray[sCount++] = new ComSerializedField(t, n, v);
        }
        else
        {
            int len = serializedArray.Length;
            ComSerializedField[] arr = new ComSerializedField[(len > 0 ? len * 2 : 2)];
            serializedArray.CopyTo(arr, 0);
            serializedArray = arr;
            AddSField(t, n, v);
        }
    }
    public void DelSField(int i)
    {
        if (i < serializedArray.Length)
        {
            for (int j = i; j < serializedArray.Length - 1; j++)
            {
                serializedArray[j] = serializedArray[j + 1];
            }
            serializedArray[serializedArray.Length - 1] = null;
            sCount--;
        }
    }
    public void ClearSFields()
    {
        for (int i = 0; i < serializedArray.Length; i++)
        {
            serializedArray[i] = null;
        }
        sCount = 0;
    }
    // 序列化前
    // 如果这个组件当前正在 Inspector 中显示，那么这个函数一直被调用，似乎是每帧
    // 应该只是在编辑器环境下有用
    public void OnBeforeSerialize()
    {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < serializedArray.Length; i++)
        {
            var v = serializedArray[i];
            if (v == null)
                break;
            sb.AppendFormat("{0}/{1}={2};", v.type, v.name, v.value.ToString());
        }
        string oldString = serializedString;
        serializedString = sb.ToString();
        if (oldString != serializedString)
        {
            seralizeChanged = true;
        }
    }
    public void OnAfterDeserialize()
    {
        sCount = 0;
        int startIndex = 0;
        while (true)
        {
            int semicolon = serializedString.IndexOf(';', startIndex);
            if (semicolon < 0) break;
            int slash = serializedString.IndexOf('/', startIndex);
            if (slash < 0) break;
            int equal = serializedString.IndexOf('=', slash + 1);
            if (equal < 0) break;

            string type = serializedString.Substring(startIndex, slash - startIndex);
            string name = serializedString.Substring(slash + 1, equal - slash - 1);
            string sValue = serializedString.Substring(equal + 1, semicolon - equal - 1);

            if (type == "Int")
            {
                AddSField(type, name, int.Parse(sValue));
            }
            else if (type == "Bool")
            {
                AddSField(type, name, bool.Parse(sValue));
            }
            else if (type == "Float")
            {
                AddSField(type, name, float.Parse(sValue));
            }

            //Debug.Log(type+"/"+name+"="+sValue);

            startIndex = semicolon + 1;
        }

        seralizeChanged = true;
    }
}
